### AGENTE - DIRETRIZES GERAIS

#### OBJETIVO
Manter código coeso, modular e limpo durante o desenvolvimento do app PWA de publicação de vídeos com React, Supabase e Material UI.

---

### ESTRUTURA
- Usar sempre a estrutura padrão:
  /components, /pages, /services, /hooks, /utils, /assets, /docs.
- Nunca criar arquivos fora dessa hierarquia.
- Nenhum arquivo deve ultrapassar 300 linhas.
- Dividir componentes grandes em subcomponentes.
- Reutilizar o que já existe antes de criar algo novo.

---

### CÓDIGO
- Linguagem: TypeScript.
- Seguir ESLint + Prettier.
- Nenhum `any` sem justificativa.
- Hooks em /hooks e iniciando com `use`.
- Serviços em /services.
- Nunca fazer chamadas HTTP dentro de componentes.
- Centralizar constantes e endpoints em /config.

---

### UI/UX
- Design mobile-first.
- Usar exclusivamente Material UI (sem CSS inline).
- Sem lógica de negócio em componentes visuais.
- Usar tema global para cores e tipografia.

---

### DUPLICAÇÃO
- Antes de criar algo, verificar se já existe função/componente semelhante.
- Se houver, reutilizar ou refatorar.
- Proibido copiar e colar código de outro módulo.

---

### SEGURANÇA E AMBIENTE
- Nunca expor tokens ou chaves.
- Usar `.env` para credenciais.
- Supabase Auth obrigatório.
- APIs externas separadas em módulos próprios.
- Evitar dependências não essenciais.

---

### INTELIGÊNCIA ARTIFICIAL
- Nunca sobrescrever código funcional sem confirmação.
- Antes de alterar algo, verificar dependências.
- Sempre preservar lógica existente.
- Se dúvida: perguntar antes de substituir.

---

### TESTES E DOCUMENTAÇÃO
- Criar testes básicos para serviços e hooks.
- Documentar cada nova feature em /docs.
- Incluir propósito, dependências e fluxo de dados.
- Revisar docs antes de qualquer refatoração.

---

### PERFORMANCE
- Usar memoização (`useMemo`, `useCallback`).
- Lazy-load em rotas pesadas.
- Limpar listeners e timers em useEffect.
- Evitar blocos síncronos pesados na UI.

---

### NUNCA FAZER
- Duplicar código existente.
- Criar funções utilitárias redundantes.
- Alterar código funcional sem análise.
- Inserir dados sensíveis no código.
- Misturar lógica de negócio com UI.

---

### LEMBRETE
Este agente deve sempre:
✅ Reutilizar código.
✅ Manter consistência.
✅ Criar código limpo e modular.
❌ Nunca gerar blocos massivos e confusos.
❌ Nunca quebrar código funcional existente.
